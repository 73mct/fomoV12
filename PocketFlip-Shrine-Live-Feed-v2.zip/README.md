# PocketFlip — Shrine live-feed build

This is a separate Android source project. It does not modify or depend on the existing `FomoPaper` repository.

## What changed

- Uses Shrine's `GET /api/token-info?mint=...` endpoint to resolve token metadata and the active Solana pool.
- Uses Shrine's free Socket.IO `subscribe` event and listens for `token_update` price/market-cap updates.
- Re-subscribes on Socket.IO reconnects and checks the subscription acknowledgement.
- Uses DexScreener only as a metadata fallback, and only accepts pairs whose **base token mint exactly matches** the pasted CA. It will not display a random quote-token pair as the requested token.
- Displays `CONNECTING` or `STALE` until a recent live price has arrived. Paper buys are blocked unless a valid live price update was received in the last 15 seconds.
- Removes the hard-coded demo Popcat balance/market-cap display on a fresh installation.

The price feed is sourced from Shrine's public Solana Data API. Shrine documents [`/api/token-info`](https://shrine.trade/pump/wallet/token-info/) and the keyless [`subscribe` / `token_update` Socket.IO feed](https://shrine.trade/pump/data-api/subscribe/). The feed is public and free/keyless under its published free-tier limits; it is not FOMO's private backend.

## Upload/build

1. Create a **new, separate** GitHub repository for this project. Do not reuse `FomoPaper`.
2. Upload this ZIP file to the root of the new repository (or extract it locally and upload the ZIP's contents to the repository root).
3. Open the repository's **Actions** tab. The included workflow extracts the ZIP when needed, builds the debug APK, and uploads it as an artifact named `PocketFlip-debug-apk`.
4. Open the completed workflow run and download the `PocketFlip-debug-apk` artifact. Inside it is `app-debug.apk`.

## Important verification note

This source package has not been built in an Android SDK environment in this session. The included GitHub Actions workflow is there to run the real Gradle/Android build after upload. Do not install an APK unless that workflow completes successfully.

## Feed behavior

- A token with no active Shrine pool, or one that has not yet produced a valid USD price update, stays in `CONNECTING` and cannot be paper-bought.
- When no live event has arrived for more than 15 seconds, the market-cap display is marked `STALE` and paper buys are blocked until fresh data resumes.
- The app remains paper trading only. It does not connect a wallet or submit real Solana transactions.
