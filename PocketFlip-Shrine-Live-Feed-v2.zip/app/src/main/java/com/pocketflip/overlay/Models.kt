package com.pocketflip.overlay

import java.util.Locale
import kotlin.math.abs

data class TokenInfo(
    val ca: String,
    val name: String,
    val symbol: String,
    val priceUsd: Double,
    val solUsdPrice: Double,
    val marketCap: Double,
    val liquidityUsd: Double,
    val volume24h: Double,
    val imageUrl: String
)

data class OpenPosition(
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    var entryMc: Double,
    var entryPriceUsd: Double,
    var solInvested: Double,
    var initialSolInvested: Double,
    var tokensHeld: Double,
    var remainingPct: Double,
    var realizedPnlSol: Double,
    val openedAtMs: Long,
    var lastMc: Double,
    var lastPriceUsd: Double
)

data class ClosedTradeLog(
    val id: String,
    val ca: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val boughtMc: Double,
    val soldMc: Double,
    val solIn: Double,
    val solOut: Double,
    val pnlSol: Double,
    val multipleX: Double,
    val soldPct: Double,
    val remainingPctAfter: Double,
    val holdDurationMs: Long,
    val closedAtMs: Long
)

data class AppSettings(
    var solBalance: Double = 10.0,
    var solUsdPrice: Double = 185.0,
    var platformFeePct: Double = 1.0,
    var priorityFeeSol: Double = 0.005,
    var slippagePct: Double = 1.5,
    var buyPresets: List<Double> = listOf(0.25, 0.5, 1.0, 2.5),
    var sellPresets: List<Double> = listOf(25.0, 30.0, 50.0, 100.0),
    var activeCa: String = ""
)

object Formatters {
    fun compactUsd(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite()) 0.0 else value
        return when {
            v >= 1_000_000_000.0 -> String.format(Locale.US, "$%.2fB", v / 1_000_000_000.0)
            v >= 1_000_000.0 -> String.format(Locale.US, "$%.2fM", v / 1_000_000.0)
            v >= 1_000.0 -> String.format(Locale.US, "$%.1fK", v / 1_000.0)
            else -> String.format(Locale.US, "$%.2f", v)
        }
    }

    fun solSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.3f SOL", sign, abs(value))
    }

    fun pctSigned(value: Double): String {
        val sign = if (value >= 0.0) "+" else "-"
        return String.format(Locale.US, "%s%.0f%%", sign, abs(value))
    }

    fun multX(value: Double): String {
        val v = if (value.isNaN() || value.isInfinite() || value <= 0.0) 1.0 else value
        return String.format(Locale.US, "%.2fx", v)
    }

    fun duration(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(1L)
        val hrs = totalSec / 3600L
        val mins = (totalSec % 3600L) / 60L
        val secs = totalSec % 60L
        return when {
            hrs > 0L -> "${hrs}h ${mins}m ${secs}s"
            mins > 0L -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }

    fun shortCa(ca: String): String {
        if (ca.length <= 12) return ca
        return ca.take(6) + "..." + ca.takeLast(5)
    }
}
