package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max
import kotlin.math.roundToInt

object TradeRepository {
    private const val PREFS_NAME = "pocketflip_native_store"
    private const val KEY_SETTINGS = "settings_json"
    private const val KEY_POSITIONS = "positions_json"
    private const val KEY_JOURNAL = "journal_json"

    private var prefs: SharedPreferences? = null
    var settings: AppSettings = AppSettings()
        private set

    private val positionsMap = LinkedHashMap<String, OpenPosition>()
    private val journalList = ArrayList<ClosedTradeLog>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadFromPrefs()
    }

    fun addListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l.invoke()
            } catch (_: Throwable) {}
        }
    }

    @Synchronized
    fun getPosition(ca: String): OpenPosition? = positionsMap[ca]

    @Synchronized
    fun getAllPositions(): List<OpenPosition> = ArrayList(positionsMap.values)

    @Synchronized
    fun getJournal(): List<ClosedTradeLog> = ArrayList(journalList)

    @Synchronized
    fun setActiveCa(ca: String) {
        settings.activeCa = ca.trim()
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun updateSettings(
        newBalance: Double,
        platformFeePct: Double,
        priorityFeeSol: Double,
        slippagePct: Double,
        buyPresets: List<Double>,
        sellPresets: List<Double>
    ) {
        settings.solBalance = newBalance.coerceAtLeast(0.0)
        settings.platformFeePct = platformFeePct.coerceIn(0.0, 25.0)
        settings.priorityFeeSol = priorityFeeSol.coerceIn(0.0, 2.0)
        settings.slippagePct = slippagePct.coerceIn(0.0, 50.0)
        if (buyPresets.size == 4) settings.buyPresets = buyPresets
        if (sellPresets.size == 4) settings.sellPresets = sellPresets
        saveToPrefs()
        notifyListeners()
    }

    @Synchronized
    fun syncLiveTokenData(token: TokenInfo) {
        if (token.solUsdPrice > 5.0) {
            settings.solUsdPrice = token.solUsdPrice
        }
        val pos = positionsMap[token.ca]
        if (pos != null) {
            pos.lastMc = token.marketCap
            pos.lastPriceUsd = token.priceUsd
        }
        notifyListeners()
    }

    @Synchronized
    fun executeBuy(token: TokenInfo, buySol: Double): Result<OpenPosition> {
        if (token.priceUsd <= 0.0 || token.marketCap <= 0.0 ||
            !token.priceUsd.isFinite() || !token.marketCap.isFinite()) {
            return Result.failure(IllegalStateException("No valid live token price yet. Wait for the feed before buying."))
        }
        if (buySol <= 0.0) {
            return Result.failure(IllegalArgumentException("Enter a valid SOL buy amount"))
        }
        val totalCostSol = buySol + settings.priorityFeeSol
        if (totalCostSol > settings.solBalance) {
            return Result.failure(
                IllegalStateException(
                    "Insufficient SOL! Need ${String.format("%.3f", totalCostSol)} SOL (incl. fee)"
                )
            )
        }

        val priceUsd = token.priceUsd.coerceAtLeast(0.0000000001)
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)
        val feeMult = (1.0 - settings.platformFeePct / 100.0) * (1.0 - settings.slippagePct / 100.0)
        val effectiveSol = buySol * feeMult
        val tokensBought = (effectiveSol * solUsd) / priceUsd

        settings.solBalance = max(0.0, settings.solBalance - totalCostSol)

        val existing = positionsMap[token.ca]
        val updated = if (existing == null) {
            OpenPosition(
                ca = token.ca,
                name = token.name,
                symbol = token.symbol,
                imageUrl = token.imageUrl,
                entryMc = token.marketCap,
                entryPriceUsd = priceUsd,
                solInvested = totalCostSol,
                initialSolInvested = totalCostSol,
                tokensHeld = tokensBought,
                remainingPct = 100.0,
                realizedPnlSol = 0.0,
                openedAtMs = System.currentTimeMillis(),
                lastMc = token.marketCap,
                lastPriceUsd = priceUsd
            )
        } else {
            val totalTokens = existing.tokensHeld + tokensBought
            val prevWeight = existing.tokensHeld / totalTokens
            val newWeight = tokensBought / totalTokens
            existing.entryMc = existing.entryMc * prevWeight + token.marketCap * newWeight
            existing.entryPriceUsd = existing.entryPriceUsd * prevWeight + priceUsd * newWeight
            existing.tokensHeld = totalTokens
            existing.solInvested += totalCostSol
            existing.initialSolInvested += totalCostSol
            existing.remainingPct = 100.0
            existing.lastMc = token.marketCap
            existing.lastPriceUsd = priceUsd
            existing
        }

        positionsMap[token.ca] = updated
        saveToPrefs()
        notifyListeners()
        return Result.success(updated)
    }

    @Synchronized
    fun executeSell(token: TokenInfo, sellPctInput: Double): Result<ClosedTradeLog> {
        val pos = positionsMap[token.ca]
            ?: return Result.failure(IllegalStateException("No open position for ${token.symbol}"))

        val pct = sellPctInput.coerceIn(1.0, 100.0)
        val fraction = pct / 100.0
        val tokensSold = pos.tokensHeld * fraction
        val solCostBasis = pos.solInvested * fraction

        val currentPriceUsd = if (token.ca == pos.ca && token.priceUsd > 0.0) token.priceUsd else pos.lastPriceUsd
        val currentMc = if (token.ca == pos.ca && token.marketCap > 0.0) token.marketCap else pos.lastMc
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)

        val grossSolOut = (tokensSold * currentPriceUsd) / solUsd
        val feeMult = (1.0 - settings.platformFeePct / 100.0) * (1.0 - settings.slippagePct / 100.0)
        val netSolOut = max(0.0, grossSolOut * feeMult - settings.priorityFeeSol)

        settings.solBalance += netSolOut

        val pnlSol = netSolOut - solCostBasis
        val multipleX = if (pos.entryMc > 0.0) (currentMc / pos.entryMc) else 1.0
        val holdDurationMs = (System.currentTimeMillis() - pos.openedAtMs).coerceAtLeast(1000L)

        val remainingAfter = if (pct >= 99.9) {
            0.0
        } else {
            max(1.0, (pos.remainingPct * (1.0 - fraction)).roundToInt().toDouble())
        }

        val log = ClosedTradeLog(
            id = "tr_${System.currentTimeMillis()}",
            ca = pos.ca,
            name = pos.name,
            symbol = pos.symbol,
            imageUrl = if (token.imageUrl.isNotEmpty()) token.imageUrl else pos.imageUrl,
            boughtMc = pos.entryMc,
            soldMc = currentMc,
            solIn = solCostBasis,
            solOut = netSolOut,
            pnlSol = pnlSol,
            multipleX = multipleX,
            soldPct = pct,
            remainingPctAfter = remainingAfter,
            holdDurationMs = holdDurationMs,
            closedAtMs = System.currentTimeMillis()
        )

        journalList.add(0, log)

        if (pct >= 99.9) {
            positionsMap.remove(pos.ca)
        } else {
            pos.tokensHeld -= tokensSold
            pos.solInvested -= solCostBasis
            pos.remainingPct = remainingAfter
            pos.realizedPnlSol += pnlSol
        }

        saveToPrefs()
        notifyListeners()
        return Result.success(log)
    }

    @Synchronized
    fun computeUnrealizedPnlSol(pos: OpenPosition, livePriceUsd: Double): Double {
        val solUsd = settings.solUsdPrice.coerceAtLeast(10.0)
        val grossSol = (pos.tokensHeld * livePriceUsd) / solUsd
        val feeMult = (1.0 - settings.platformFeePct / 100.0) * (1.0 - settings.slippagePct / 100.0)
        val netSolVal = max(0.0, grossSol * feeMult - settings.priorityFeeSol)
        return netSolVal - pos.solInvested
    }

    @Synchronized
    fun clearJournal() {
        journalList.clear()
        saveToPrefs()
        notifyListeners()
    }

    private fun saveToPrefs() {
        val p = prefs ?: return
        val settingsObj = JSONObject().apply {
            put("solBalance", settings.solBalance)
            put("solUsdPrice", settings.solUsdPrice)
            put("platformFeePct", settings.platformFeePct)
            put("priorityFeeSol", settings.priorityFeeSol)
            put("slippagePct", settings.slippagePct)
            put("activeCa", settings.activeCa)
            put("buyPresets", JSONArray(settings.buyPresets))
            put("sellPresets", JSONArray(settings.sellPresets))
        }

        val posArr = JSONArray()
        for (pos in positionsMap.values) {
            posArr.put(JSONObject().apply {
                put("ca", pos.ca)
                put("name", pos.name)
                put("symbol", pos.symbol)
                put("imageUrl", pos.imageUrl)
                put("entryMc", pos.entryMc)
                put("entryPriceUsd", pos.entryPriceUsd)
                put("solInvested", pos.solInvested)
                put("initialSolInvested", pos.initialSolInvested)
                put("tokensHeld", pos.tokensHeld)
                put("remainingPct", pos.remainingPct)
                put("realizedPnlSol", pos.realizedPnlSol)
                put("openedAtMs", pos.openedAtMs)
                put("lastMc", pos.lastMc)
                put("lastPriceUsd", pos.lastPriceUsd)
            })
        }

        val journalArr = JSONArray()
        for (item in journalList) {
            journalArr.put(JSONObject().apply {
                put("id", item.id)
                put("ca", item.ca)
                put("name", item.name)
                put("symbol", item.symbol)
                put("imageUrl", item.imageUrl)
                put("boughtMc", item.boughtMc)
                put("soldMc", item.soldMc)
                put("solIn", item.solIn)
                put("solOut", item.solOut)
                put("pnlSol", item.pnlSol)
                put("multipleX", item.multipleX)
                put("soldPct", item.soldPct)
                put("remainingPctAfter", item.remainingPctAfter)
                put("holdDurationMs", item.holdDurationMs)
                put("closedAtMs", item.closedAtMs)
            })
        }

        p.edit()
            .putString(KEY_SETTINGS, settingsObj.toString())
            .putString(KEY_POSITIONS, posArr.toString())
            .putString(KEY_JOURNAL, journalArr.toString())
            .apply()
    }

    private fun loadFromPrefs() {
        val p = prefs ?: return
        try {
            val sRaw = p.getString(KEY_SETTINGS, null)
            if (!sRaw.isNullOrEmpty()) {
                val o = JSONObject(sRaw)
                val buys = ArrayList<Double>()
                val bArr = o.optJSONArray("buyPresets")
                if (bArr != null && bArr.length() == 4) {
                    for (i in 0 until 4) buys.add(bArr.optDouble(i, 0.5))
                } else {
                    buys.addAll(listOf(0.25, 0.5, 1.0, 2.5))
                }
                val sells = ArrayList<Double>()
                val sArr = o.optJSONArray("sellPresets")
                if (sArr != null && sArr.length() == 4) {
                    for (i in 0 until 4) sells.add(sArr.optDouble(i, 25.0))
                } else {
                    sells.addAll(listOf(25.0, 30.0, 50.0, 100.0))
                }
                settings = AppSettings(
                    solBalance = o.optDouble("solBalance", 10.0),
                    solUsdPrice = o.optDouble("solUsdPrice", 185.0),
                    platformFeePct = o.optDouble("platformFeePct", 1.0),
                    priorityFeeSol = o.optDouble("priorityFeeSol", 0.005),
                    slippagePct = o.optDouble("slippagePct", 1.5),
                    buyPresets = buys,
                    sellPresets = sells,
                    activeCa = o.optString("activeCa", "")
                )
            }

            val posRaw = p.getString(KEY_POSITIONS, null)
            positionsMap.clear()
            if (!posRaw.isNullOrEmpty()) {
                val arr = JSONArray(posRaw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val pos = OpenPosition(
                        ca = o.optString("ca"),
                        name = o.optString("name", "Token"),
                        symbol = o.optString("symbol", "TOK"),
                        imageUrl = o.optString("imageUrl", ""),
                        entryMc = o.optDouble("entryMc", 10000.0),
                        entryPriceUsd = o.optDouble("entryPriceUsd", 0.0001),
                        solInvested = o.optDouble("solInvested", 1.0),
                        initialSolInvested = o.optDouble("initialSolInvested", 1.0),
                        tokensHeld = o.optDouble("tokensHeld", 1000.0),
                        remainingPct = o.optDouble("remainingPct", 100.0),
                        realizedPnlSol = o.optDouble("realizedPnlSol", 0.0),
                        openedAtMs = o.optLong("openedAtMs", System.currentTimeMillis()),
                        lastMc = o.optDouble("lastMc", 10000.0),
                        lastPriceUsd = o.optDouble("lastPriceUsd", 0.0001)
                    )
                    if (pos.ca.isNotEmpty()) positionsMap[pos.ca] = pos
                }
            }

            val jRaw = p.getString(KEY_JOURNAL, null)
            journalList.clear()
            if (!jRaw.isNullOrEmpty()) {
                val arr = JSONArray(jRaw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    journalList.add(
                        ClosedTradeLog(
                            id = o.optString("id"),
                            ca = o.optString("ca"),
                            name = o.optString("name"),
                            symbol = o.optString("symbol"),
                            imageUrl = o.optString("imageUrl"),
                            boughtMc = o.optDouble("boughtMc", 0.0),
                            soldMc = o.optDouble("soldMc", 0.0),
                            solIn = o.optDouble("solIn", 0.0),
                            solOut = o.optDouble("solOut", 0.0),
                            pnlSol = o.optDouble("pnlSol", 0.0),
                            multipleX = o.optDouble("multipleX", 1.0),
                            soldPct = o.optDouble("soldPct", 100.0),
                            remainingPctAfter = o.optDouble("remainingPctAfter", 0.0),
                            holdDurationMs = o.optLong("holdDurationMs", 1000L),
                            closedAtMs = o.optLong("closedAtMs", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Throwable) {}
    }
}
