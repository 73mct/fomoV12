package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import io.socket.client.Ack
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object DexScreenerClient {
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val base58Regex = Regex("[1-9A-HJ-NP-Za-km-z]{32,44}")
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private const val WSOL_MINT = "So11111111111111111111111111111111111111112"
    private const val SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    private const val TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
    private const val RAYDIUM_V4_PROGRAM = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"

    // Persistent HTTP/2 & WebSocket client (zero TCP/TLS handshake overhead on subsequent polls!)
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5000, TimeUnit.MILLISECONDS)
        .readTimeout(5000, TimeUnit.MILLISECONDS)
        .writeTimeout(5000, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val SOLANA_HTTP_RPCS = arrayOf(
        "https://solana-rpc.publicnode.com",
        "https://api.mainnet-beta.solana.com"
    )
    private val SOLANA_WS_RPCS = arrayOf(
        "wss://solana-rpc.publicnode.com",
        "wss://api.mainnet-beta.solana.com"
    )
    private val rpcIndex = AtomicInteger(0)

    private enum class PoolKind {
        PUMPFUN_CURVE,
        DUAL_SPL_VAULTS
    }

    private data class LivePoolConfig(
        val ca: String,
        val pairAddress: String,
        val kind: PoolKind,
        val tokenVault: String,
        val solVault: String,
        var baseRatio: Double,
        var baseMc: Double,
        var basePriceUsd: Double
    )

    private val poolConfigMap = ConcurrentHashMap<String, LivePoolConfig>()
    private val tokenMetaMap = ConcurrentHashMap<String, TokenInfo>()
    private val tokenSupplyMap = ConcurrentHashMap<String, Double>()
    private val lastLivePriceAtMs = ConcurrentHashMap<String, Long>()
    private val lastMetadataAttemptAtMs = ConcurrentHashMap<String, Long>()

    @Volatile
    private var activePumpWebSocket: WebSocket? = null

    @Volatile
    private var activeSolanaWebSocket: WebSocket? = null

    @Volatile
    private var shrineSocket: Socket? = null

    @Volatile
    private var subscribedCa: String = ""

    fun extractSolanaCa(rawClipboard: String): String {
        val trimmed = rawClipboard.trim()
        val match = base58Regex.find(trimmed)
        return match?.value ?: trimmed
    }

    /**
     * Resolve a mint using Shrine's token registry first. That registry resolves the
     * currently active pool (including Pump.fun -> PumpSwap migrations); DexScreener
     * is only a strict mint-matched metadata fallback. The live price itself comes
     * from Shrine's token_update Socket.IO stream.
     */
    @Synchronized
    fun fetchInitialTokenMetadata(rawCa: String, onRealtimeUpdate: (TokenInfo) -> Unit): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (!isValidSolanaMint(ca)) return null

        val existing = tokenMetaMap[ca]
        if (existing != null) {
            ensureWebSocketsRunning(ca, onRealtimeUpdate)
            return existing
        }

        val now = System.currentTimeMillis()
        val lastTry = lastMetadataAttemptAtMs[ca] ?: 0L
        if (now - lastTry < 1800L) return null
        lastMetadataAttemptAtMs[ca] = now

        val parsed = fetchShrineTokenInfo(ca) ?: fetchDexScreenerFallback(ca)
        if (parsed == null) return null

        tokenMetaMap[ca] = parsed
        if (parsed.priceUsd > 0.0 && parsed.marketCap > 0.0) {
            // A REST snapshot may populate the display, but it is not considered a
            // live tick. Buying remains disabled until token_update arrives.
        }
        ensureWebSocketsRunning(ca, onRealtimeUpdate)
        return parsed
    }

    /** True only after a valid Shrine live tick received recently for this mint. */
    fun hasRecentLivePrice(rawCa: String, maxAgeMs: Long = 15_000L): Boolean {
        val ca = extractSolanaCa(rawCa)
        val updatedAt = lastLivePriceAtMs[ca] ?: return false
        return System.currentTimeMillis() - updatedAt in 0..maxAgeMs &&
            (tokenMetaMap[ca]?.let { it.priceUsd > 0.0 && it.marketCap > 0.0 } == true)
    }

    private fun isValidSolanaMint(ca: String): Boolean =
        ca.length in 32..44 && base58Regex.matches(ca)

    private fun fetchShrineTokenInfo(ca: String): TokenInfo? {
        val request = Request.Builder()
            .url("https://sol.shrine.trade/api/token-info?mint=$ca")
            .header("Cache-Control", "no-cache, no-store")
            .header("Pragma", "no-cache")
            .build()
        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val obj = JSONObject(body)
                if (obj.optString("mint") != ca) return null

                val priceUsd = jsonNumber(obj, "priceUSD", "priceUsd")
                val marketCapUsd = jsonNumber(obj, "marketCapUSD", "mcapUSD", "marketCapUsd")
                val supply = jsonNumber(obj, "totalSupply", "total_supply")
                if (supply > 0.0) tokenSupplyMap[ca] = supply

                val name = obj.optString("name", "Solana Token").ifBlank { "Solana Token" }
                val symbol = obj.optString("symbol", "TOKEN").ifBlank { "TOKEN" }
                val solUsd = jsonNumber(obj, "solPriceUSD", "solUsdPrice")
                    .takeIf { it in 10.0..2000.0 } ?: TradeRepository.settings.solUsdPrice
                val image = obj.optString("image", "")

                TokenInfo(
                    ca = ca,
                    name = name,
                    symbol = symbol,
                    priceUsd = priceUsd.takeIf { it > 0.0 && it.isFinite() } ?: 0.0,
                    solUsdPrice = solUsd,
                    marketCap = marketCapUsd.takeIf { it > 0.0 && it.isFinite() } ?: 0.0,
                    liquidityUsd = 0.0,
                    volume24h = 0.0,
                    imageUrl = image
                )
            }
        } catch (t: Throwable) {
            Log.w("PocketFlipFeed", "Shrine token-info lookup failed", t)
            null
        }
    }

    private fun fetchDexScreenerFallback(ca: String): TokenInfo? {
        val directUrl = "https://api.dexscreener.com/token-pairs/v1/solana/$ca"
        val pair = fetchBestSolanaPairJson(directUrl, isArray = true, expectedMint = ca)
            ?: fetchBestSolanaPairJson(
                "https://api.dexscreener.com/latest/dex/tokens/$ca",
                isArray = false,
                expectedMint = ca
            )
            ?: return null
        return parsePairToTokenInfo(pair, ca)
    }

    private fun jsonNumber(obj: JSONObject, vararg keys: String): Double {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val value = obj.opt(key)
            val parsed = when (value) {
                is Number -> value.toDouble()
                is String -> value.toDoubleOrNull() ?: 0.0
                else -> 0.0
            }
            if (parsed.isFinite() && parsed > 0.0) return parsed
        }
        return 0.0
    }

    /**
     * Legacy RPC reserve reader retained as a fallback utility. The overlay uses
     * Shrine's trade-driven token_update stream for its primary live price feed.
     */
    fun pollLiveOnChainPrice(rawCa: String, onRealtimeUpdate: (TokenInfo) -> Unit): TokenInfo? {
        val ca = extractSolanaCa(rawCa)
        if (ca.length < 20) return null

        val meta = tokenMetaMap[ca] ?: return fetchInitialTokenMetadata(ca, onRealtimeUpdate)
        ensureWebSocketsRunning(ca, onRealtimeUpdate)

        val cfg = poolConfigMap[ca]
        if (cfg == null) {
            return meta
        }

        return when (cfg.kind) {
            PoolKind.PUMPFUN_CURVE -> pollPumpFunBondingCurve(cfg, meta)
            PoolKind.DUAL_SPL_VAULTS -> pollDualSplVaults(cfg, meta)
        }
    }

    /**
     * Decodes Pump.fun Bonding Curve account (`pairAddress`) bytes 8..23:
     * bytes 8..15  = virtualTokenReserves (u64 LE, 6 decimals)
     * bytes 16..23 = virtualSolReserves   (u64 LE, 9 decimals)
     * Price in SOL = (virtualSolReserves / 1e9) / (virtualTokenReserves / 1e6)
     * Market Cap USD = Price in SOL * 1,000,000,000 * solUsdPrice
     */
    private fun pollPumpFunBondingCurve(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getAccountInfo")
            put("params", JSONArray().apply {
                put(cfg.pairAddress)
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val accVal = resp.optJSONObject("result")?.optJSONObject("value") ?: return null
        return applyPumpCurveAccountBytes(cfg, meta, accVal)
    }

    private fun applyPumpCurveAccountBytes(cfg: LivePoolConfig, meta: TokenInfo, accVal: JSONObject): TokenInfo? {
        val dataArr = accVal.optJSONArray("data") ?: return null
        val b64 = dataArr.optString(0, "")
        if (b64.isEmpty()) return null
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        if (bytes.size < 24) return null

        val vTokenRaw = readU64Le(bytes, 8)
        val vSolRaw = readU64Le(bytes, 16)
        if (vTokenRaw <= 0.0 || vSolRaw <= 0.0) return null

        val currentRatio = vSolRaw / vTokenRaw
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
        }

        // Exact on-chain Pump.fun Market Cap formula: (vSol / 1e9) / (vToken / 1e6) * 1e9 * solUsdPrice
        val priceInSol = (vSolRaw / 1_000_000_000.0) / (vTokenRaw / 1_000_000.0)
        val directMcUsd = priceInSol * 1_000_000_000.0 * meta.solUsdPrice
        val directPriceUsd = priceInSol * meta.solUsdPrice

        val updated = if (directMcUsd in 500.0..50_000_000_000.0) {
            meta.copy(
                marketCap = directMcUsd,
                priceUsd = directPriceUsd
            )
        } else {
            val mult = currentRatio / cfg.baseRatio
            meta.copy(
                marketCap = cfg.baseMc * mult,
                priceUsd = cfg.basePriceUsd * mult
            )
        }
        tokenMetaMap[cfg.ca] = updated
        return updated
    }

    /**
     * Reads both the pool's SPL Token Vault and WSOL Vault in a single `getMultipleAccounts` call
     * with "commitment": "processed" (works for PumpSwap, Raydium AMM/CPMM/CLMM, Meteora, Orca).
     */
    private fun pollDualSplVaults(cfg: LivePoolConfig, meta: TokenInfo): TokenInfo? {
        val reqObj = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(cfg.tokenVault)
                    put(cfg.solVault)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val resp = postSolanaRpc(reqObj.toString()) ?: return null
        val arr = resp.optJSONObject("result")?.optJSONArray("value") ?: return null
        if (arr.length() < 2) return null

        val tokAcc = arr.optJSONObject(0) ?: return null
        val solAcc = arr.optJSONObject(1) ?: return null

        val tokReserve = decodeSplAccountBalance(tokAcc)
        val solReserve = decodeSplAccountBalance(solAcc).let {
            if (it > 0.0) it else (solAcc.optLong("lamports", 0L).toDouble())
        }

        if (tokReserve <= 0.0 || solReserve <= 0.0) return null
        val currentRatio = solReserve / tokReserve
        if (cfg.baseRatio <= 0.0) {
            cfg.baseRatio = currentRatio
            return meta
        }

        val mult = currentRatio / cfg.baseRatio
        if (mult.isNaN() || mult.isInfinite() || mult <= 0.0001 || mult >= 10000.0) return null

        val updated = meta.copy(
            marketCap = cfg.baseMc * mult,
            priceUsd = cfg.basePriceUsd * mult
        )
        tokenMetaMap[cfg.ca] = updated
        return updated
    }

    /**
     * Inspects `pairAddress` on-chain once to determine whether it's a Pump.fun Bonding Curve,
     * a Raydium v4 AMM pool, or a PumpSwap/CPMM/Meteora pool owning two SPL token vaults.
     */
    private fun initOnChainPoolForPair(ca: String, pairAddress: String, initialMeta: TokenInfo) {
        try {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getAccountInfo")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply {
                        put("encoding", "base64")
                        put("commitment", "processed")
                    })
                })
            }
            val resp = postSolanaRpc(req.toString()) ?: return
            val valObj = resp.optJSONObject("result")?.optJSONObject("value") ?: return
            val ownerProgram = valObj.optString("owner", "")
            val dataArr = valObj.optJSONArray("data")
            val b64 = dataArr?.optString(0, "") ?: ""
            val bytes = if (b64.isNotEmpty()) Base64.decode(b64, Base64.DEFAULT) else ByteArray(0)

            // Case 1: Pump.fun Bonding Curve (49..250 bytes, or owned by 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P)
            if (ownerProgram.startsWith("6EF8r") || (bytes.size in 49..260)) {
                val vTok = readU64Le(bytes, 8)
                val vSol = readU64Le(bytes, 16)
                if (vTok > 0.0 && vSol > 0.0) {
                    val cfg = LivePoolConfig(
                        ca = ca,
                        pairAddress = pairAddress,
                        kind = PoolKind.PUMPFUN_CURVE,
                        tokenVault = pairAddress,
                        solVault = pairAddress,
                        baseRatio = vSol / vTok,
                        baseMc = initialMeta.marketCap,
                        basePriceUsd = initialMeta.priceUsd
                    )
                    poolConfigMap[ca] = cfg
                    applyPumpCurveAccountBytes(cfg, initialMeta, valObj)
                    return
                }
            }

            // Case 2: Raydium AMM v4 (752 bytes, baseVault at 336..368, quoteVault at 368..400)
            if (ownerProgram == RAYDIUM_V4_PROGRAM && bytes.size >= 400) {
                val vaultA = encodeBase58(bytes.copyOfRange(336, 368))
                val vaultB = encodeBase58(bytes.copyOfRange(368, 400))
                setupDualVaultConfig(ca, pairAddress, vaultA, vaultB, initialMeta)
                return
            }

            // Case 3: PumpSwap / Raydium CPMM / Meteora / Orca — discover vaults via getTokenAccountsByOwner(pairAddress)
            val vaults = findPoolVaultsByOwner(pairAddress, ca)
            if (vaults != null) {
                setupDualVaultConfig(ca, pairAddress, vaults.first, vaults.second, initialMeta)
            }
        } catch (_: Throwable) {}
    }

    private fun findPoolVaultsByOwner(pairAddress: String, tokenMintCa: String): Pair<String, String>? {
        var tokVault = ""
        var wsolVault = ""

        for (prog in arrayOf(SPL_TOKEN_PROGRAM, TOKEN_2022_PROGRAM)) {
            val req = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "getTokenAccountsByOwner")
                put("params", JSONArray().apply {
                    put(pairAddress)
                    put(JSONObject().apply { put("programId", prog) })
                    put(JSONObject().apply {
                        put("encoding", "jsonParsed")
                        put("commitment", "processed")
                    })
                })
            }
            val res = postSolanaRpc(req.toString()) ?: continue
            val arr = res.optJSONObject("result")?.optJSONArray("value") ?: continue
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val pubkey = item.optString("pubkey", "")
                val info = item.optJSONObject("account")
                    ?.optJSONObject("data")
                    ?.optJSONObject("parsed")
                    ?.optJSONObject("info") ?: continue
                val mint = info.optString("mint", "")
                if (mint == tokenMintCa && pubkey.isNotEmpty()) {
                    tokVault = pubkey
                } else if (mint == WSOL_MINT && pubkey.isNotEmpty()) {
                    wsolVault = pubkey
                }
            }
        }

        if (tokVault.isNotEmpty() && wsolVault.isNotEmpty()) {
            return Pair(tokVault, wsolVault)
        }
        return null
    }

    private fun setupDualVaultConfig(
        ca: String,
        pairAddress: String,
        vault1: String,
        vault2: String,
        initialMeta: TokenInfo
    ) {
        val req = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "getMultipleAccounts")
            put("params", JSONArray().apply {
                put(JSONArray().apply {
                    put(vault1)
                    put(vault2)
                })
                put(JSONObject().apply {
                    put("encoding", "base64")
                    put("commitment", "processed")
                })
            })
        }
        val res = postSolanaRpc(req.toString()) ?: return
        val arr = res.optJSONObject("result")?.optJSONArray("value") ?: return
        if (arr.length() < 2) return
        val acc1 = arr.optJSONObject(0) ?: return
        val acc2 = arr.optJSONObject(1) ?: return

        val mint1 = decodeSplAccountMintBase58(acc1)
        val bal1 = decodeSplAccountBalance(acc1)
        val bal2 = decodeSplAccountBalance(acc2)
        if (bal1 <= 0.0 || bal2 <= 0.0) return

        val isVault1Token = (mint1 == ca)
        val tokVault = if (isVault1Token) vault1 else vault2
        val solVault = if (isVault1Token) vault2 else vault1
        val tokReserve = if (isVault1Token) bal1 else bal2
        val solReserve = if (isVault1Token) bal2 else bal1

        poolConfigMap[ca] = LivePoolConfig(
            ca = ca,
            pairAddress = pairAddress,
            kind = PoolKind.DUAL_SPL_VAULTS,
            tokenVault = tokVault,
            solVault = solVault,
            baseRatio = solReserve / tokReserve,
            baseMc = initialMeta.marketCap,
            basePriceUsd = initialMeta.priceUsd
        )
    }

    /** Shrine price stream. Each connect/reconnect re-subscribes to the mint. */
    @Synchronized
    private fun ensureWebSocketsRunning(ca: String, onRealtimeUpdate: (TokenInfo) -> Unit) {
        val current = shrineSocket
        if (subscribedCa == ca && current != null) {
            // Socket.IO manages reconnection itself. Do not create duplicate sockets
            // while an existing connection is still handshaking or retrying.
            return
        }

        try { current?.disconnect() } catch (_: Throwable) {}
        try { current?.close() } catch (_: Throwable) {}
        try { activePumpWebSocket?.cancel() } catch (_: Throwable) {}
        try { activeSolanaWebSocket?.cancel() } catch (_: Throwable) {}
        activePumpWebSocket = null
        activeSolanaWebSocket = null
        shrineSocket = null
        subscribedCa = ca

        try {
            val options = IO.Options().apply {
                reconnection = true
                reconnectionAttempts = Int.MAX_VALUE
                reconnectionDelay = 1000
                reconnectionDelayMax = 10000
                timeout = 15000
                forceNew = true
            }
            val socket = IO.socket("https://sol.shrine.trade", options)
            shrineSocket = socket

            socket.on(Socket.EVENT_CONNECT) {
                if (subscribedCa != ca || shrineSocket !== socket) return@on
                socket.emit("subscribe", JSONObject().put("mint", ca), Ack { ackArgs ->
                    val ack = ackArgs.firstOrNull()?.let { asJsonObject(it) }
                    if (ack?.has("error") == true) {
                        Log.w("PocketFlipFeed", "Shrine subscription rejected: ${ack.optString("error")}")
                    } else {
                        Log.i("PocketFlipFeed", "Shrine subscription acknowledged for ${ca.take(6)}…")
                    }
                })
            }

            socket.on("token_update") { args ->
                try {
                    if (subscribedCa != ca || shrineSocket !== socket) return@on
                    val update = args.firstOrNull()?.let { asJsonObject(it) } ?: return@on
                    applyShrinePriceUpdate(ca, update, onRealtimeUpdate)
                } catch (t: Throwable) {
                    Log.w("PocketFlipFeed", "Could not parse Shrine token_update", t)
                }
            }

            socket.on("subscription_error") { args ->
                val error = args.firstOrNull()?.let { asJsonObject(it) }
                Log.w("PocketFlipFeed", "Shrine subscription error: ${error?.optString("error") ?: "unknown"}")
            }
            socket.on(Socket.EVENT_CONNECT_ERROR) { args ->
                Log.w("PocketFlipFeed", "Shrine connection error: ${args.firstOrNull()}")
            }
            socket.connect()
        } catch (t: Throwable) {
            Log.e("PocketFlipFeed", "Unable to start Shrine live stream", t)
            shrineSocket = null
            subscribedCa = ""
        }
    }

    private fun applyShrinePriceUpdate(
        ca: String,
        update: JSONObject,
        onRealtimeUpdate: (TokenInfo) -> Unit
    ) {
        val old = tokenMetaMap[ca] ?: return
        val eventTime = jsonNumber(update, "time")
        val nowSeconds = System.currentTimeMillis() / 1000.0
        // Ignore obviously old replay/cached events; no event timestamp is also valid.
        if (eventTime > 0.0 && nowSeconds - eventTime > 60.0) return

        val priceUsd = jsonNumber(update, "priceUSD", "priceUsd")
        val supply = tokenSupplyMap[ca] ?: 0.0
        val marketCapFromFeed = jsonNumber(update, "mcapUSD", "marketCapUSD", "marketCapUsd")
        val marketCapUsd = when {
            marketCapFromFeed > 0.0 -> marketCapFromFeed
            priceUsd > 0.0 && supply > 0.0 -> priceUsd * supply
            else -> 0.0
        }
        if (priceUsd <= 0.0 || marketCapUsd <= 0.0 ||
            !priceUsd.isFinite() || !marketCapUsd.isFinite()) return

        val updated = old.copy(
            priceUsd = priceUsd,
            marketCap = marketCapUsd
        )
        tokenMetaMap[ca] = updated
        lastLivePriceAtMs[ca] = System.currentTimeMillis()
        onRealtimeUpdate(updated)
    }

    private fun asJsonObject(value: Any?): JSONObject? = when (value) {
        is JSONObject -> value
        is Map<*, *> -> JSONObject(value)
        is String -> try { JSONObject(value) } catch (_: Throwable) { null }
        else -> null
    }

    private fun fetchBestSolanaPairJson(
        url: String,
        isArray: Boolean,
        expectedMint: String
    ): JSONObject? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Cache-Control", "no-cache, no-store")
                .build()
            httpClient.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return null
                val raw = response.body?.string() ?: return null
                val arr = if (isArray) JSONArray(raw) else (JSONObject(raw).optJSONArray("pairs") ?: return null)

                var best: JSONObject? = null
                var bestLiquidity = -1.0
                for (i in 0 until arr.length()) {
                    val pair = arr.optJSONObject(i) ?: continue
                    if (pair.optString("chainId") != "solana") continue
                    val baseMint = pair.optJSONObject("baseToken")?.optString("address", "") ?: ""
                    // Never display a pair where the pasted CA is merely the quote token.
                    // That would silently show another coin's price/market cap.
                    if (baseMint != expectedMint) continue
                    val liquidity = jsonNumber(pair.optJSONObject("liquidity") ?: JSONObject(), "usd")
                    if (best == null || liquidity > bestLiquidity) {
                        best = pair
                        bestLiquidity = liquidity
                    }
                }
                best
            }
        } catch (t: Throwable) {
            Log.w("PocketFlipFeed", "DexScreener fallback lookup failed", t)
            null
        }
    }

    private fun parsePairToTokenInfo(pair: JSONObject, originalCa: String): TokenInfo? {
        val baseToken = pair.optJSONObject("baseToken") ?: return null
        val address = baseToken.optString("address", "")
        if (address != originalCa) return null

        val priceUsd = jsonNumber(pair, "priceUsd")
        if (priceUsd <= 0.0) return null

        val priceNative = jsonNumber(pair, "priceNative")
        val solUsd = if (priceNative > 0.0) {
            (priceUsd / priceNative).takeIf { it in 10.0..2000.0 } ?: TradeRepository.settings.solUsdPrice
        } else TradeRepository.settings.solUsdPrice

        val marketCap = jsonNumber(pair, "marketCap", "fdv")
        val vol24 = jsonNumber(pair.optJSONObject("volume") ?: JSONObject(), "h24")
        val liqUsd = jsonNumber(pair.optJSONObject("liquidity") ?: JSONObject(), "usd")
        val imageUrl = pair.optJSONObject("info")?.optString("imageUrl", "") ?: ""

        return TokenInfo(
            ca = originalCa,
            name = baseToken.optString("name", "Solana Token").ifBlank { "Solana Token" },
            symbol = baseToken.optString("symbol", "TOKEN").ifBlank { "TOKEN" },
            priceUsd = priceUsd,
            solUsdPrice = solUsd,
            marketCap = marketCap,
            liquidityUsd = liqUsd,
            volume24h = vol24,
            imageUrl = imageUrl
        )
    }

    fun loadTokenBitmap(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isEmpty()) {
            onLoaded(null)
            return
        }
        val cached = bitmapCache.get(url)
        if (cached != null) {
            onLoaded(cached)
            return
        }
        imageExecutor.execute {
            try {
                val req = Request.Builder().url(url).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null) {
                            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) bitmapCache.put(url, bmp)
                            onLoaded(bmp)
                            return@execute
                        }
                    }
                }
            } catch (_: Throwable) {}
            onLoaded(null)
        }
    }
}
